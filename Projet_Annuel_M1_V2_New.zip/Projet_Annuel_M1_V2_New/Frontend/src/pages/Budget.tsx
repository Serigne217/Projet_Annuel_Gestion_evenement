import { useState, useEffect } from "react";
import axios from "axios";
import Layout from "../components/Layout";
import { useAuth } from "../contexts/AuthContext";
import TransactionForm from "../components/TransactionForm";

interface TransactionItem {
  id_transac: number;
  date_mouvement: string;
  type: string;
  montant: number;
  description: string;
  valide: boolean;
  id_evt: number;
  id_cat: number;
  id_partenaire: number;
}

interface CategoryItem {
  id_cat: number;
  nom_categorie: string;
}

interface EventItem {
  id: number;
  titre: string;
}

export default function Budget() {
  const [transactions, setTransactions] = useState<TransactionItem[]>([]);
  const [categories, setCategories] = useState<CategoryItem[]>([]);
  const [events, setEvents] = useState<EventItem[]>([]);
  const [partners, setPartners] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<TransactionItem | null>(null);
  const { isAdmin } = useAuth();

  // RÉCUPÉRATION - Port 8090
  const fetchData = async () => {
    try {
      const [transRes, catRes, eventsRes, partnersRes] = await Promise.all([
        axios.get("http://localhost:8090/api/transactions"),
        axios.get("http://localhost:8090/api/categories"),
        axios.get("http://localhost:8090/api/events"),
        axios.get("http://localhost:8090/api/partners")
      ]);
      setTransactions(transRes.data);
      setCategories(catRes.data);
      setEvents(eventsRes.data);
      setPartners(partnersRes.data);
    } catch (error) {
      console.error("Erreur de connexion au serveur (8090):", error);
    }
  };

  const buildTransactionPayload = (data: any) => ({
    date_mouvement: data.date_mouvement,
    type: data.type === 'Dépense' ? 'Dépense' : 'Recette',
    montant: Math.abs(parseFloat(data.montant) || 0),
    description: data.description,
    valide: data.valide,
    id_evt: parseInt(data.id_evt),
    id_cat: parseInt(data.id_cat),
    id_partenaire: data.id_partenaire ? parseInt(data.id_partenaire) : null
  });

  const handleSaveTransaction = async (data: any) => {
    try {
      const transactionToSend = buildTransactionPayload(data);

      if (editingTransaction?.id_transac) {
        await axios.put(`http://localhost:8090/api/transactions/${editingTransaction.id_transac}`, transactionToSend);
      } else {
        await axios.post("http://localhost:8090/api/transactions", transactionToSend);
      }
      setEditingTransaction(null);
      setIsModalOpen(false);
      fetchData();
    } catch (error) {
      console.error("Erreur lors de l'enregistrement de la transaction:", error);
      alert("Erreur lors de l'enregistrement de la transaction.");
    }
  };

  const handleEditTransaction = (transaction: TransactionItem) => {
    if (!isAdmin) return;
    setEditingTransaction(transaction);
    setIsModalOpen(true);
  };

  const handleDeleteTransaction = async (id: number) => {
    if (!isAdmin) return;
    if (!window.confirm("Supprimer cette transaction ?")) return;
    try {
      await axios.delete(`http://localhost:8090/api/transactions/${id}`);
      fetchData();
    } catch (error) {
      console.error("Erreur lors de la suppression de la transaction:", error);
      alert("Impossible de supprimer la transaction.");
    }
  };

  // CHARGEMENT DES DONNÉES AU MONTAGE
  useEffect(() => {
    fetchData();
  }, []);

  // Calcul des statistiques
  const initialBudget = events.reduce((sum, evt) => sum + (evt.budget_alloue || 0), 0);
  const totalExpenses = transactions
    .filter(t => t.type === "Dépense" && t.valide)
    .reduce((sum, t) => sum + t.montant, 0);
  const totalReceipts = transactions
    .filter(t => t.type === "Recette" && t.valide)
    .reduce((sum, t) => sum + t.montant, 0);
  const netBalance = totalReceipts - totalExpenses;
  const availableBudget = initialBudget + netBalance;

  const getCategoryName = (id: number) => {
    const cat = categories.find(c => c.id_cat === id);
    return cat ? cat.nom_categorie : "Non catégorisée";
  };

  return (
    <Layout title="Gestion Budgétaire 2026" searchTerm={searchTerm} onSearch={setSearchTerm}>
      
      {/* 1. LES JAUGES (Ton code original amélioré) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
        {/* Budget Total */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-gray-700 text-lg">Budget disponible</h3>
            <span className="text-sm font-semibold text-gray-500">{availableBudget.toFixed(2)} €</span>
          </div>
          <div className="mb-2 flex justify-between text-sm">
            <span className="text-red-600 font-bold">Dépenses : {totalExpenses.toFixed(2)} €</span>
            <span className="text-green-600">Recettes : {totalReceipts.toFixed(2)} €</span>
          </div>
        </div>

        {/* Recettes */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-gray-700 text-lg">Recettes</h3>
          </div>
          <div className="text-3xl font-bold text-green-600">{totalReceipts.toFixed(2)} €</div>
          <p className="text-xs text-gray-400 mt-2">Crédits validés</p>
        </div>

        {/* Solde */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-gray-700 text-lg">Solde net</h3>
          </div>
          <div className={`text-3xl font-bold ${netBalance >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
            {netBalance.toFixed(2)} €
          </div>
        </div>
      </div>

      {/* 2. TABLEAU DES TRANSACTIONS */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 flex flex-col lg:flex-row lg:justify-between lg:items-center bg-gray-50/50 gap-4">
          <h3 className="font-bold text-gray-700 uppercase text-xs tracking-wider">Historique des Flux Financiers</h3>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            {!isAdmin && (
              <div className="rounded-xl bg-yellow-50 border border-yellow-200 px-4 py-3 text-sm text-yellow-700">
                Accès lecture seule : seuls les administrateurs peuvent créer de nouvelles transactions.
              </div>
            )}
            <button 
              onClick={() => {
                setEditingTransaction(null);
                setIsModalOpen(true);
              }}
              disabled={!isAdmin}
              className={`bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-lg font-bold text-sm shadow-sm transition-all ${!isAdmin ? 'bg-gray-300 hover:bg-gray-300 cursor-not-allowed' : ''}`}
            >
              + Nouvelle Transaction
            </button>
          </div>
        </div>
        
        <table className="min-w-full leading-normal">
          <thead>
            <tr className="bg-white border-b border-gray-200">
              <th className="px-5 py-3 text-left text-xs font-bold text-gray-400 uppercase">Désignation</th>
              <th className="px-5 py-3 text-left text-xs font-bold text-gray-400 uppercase">Date</th>
              <th className="px-5 py-3 text-left text-xs font-bold text-gray-400 uppercase">Catégorie</th>
              <th className="px-5 py-3 text-center text-xs font-bold text-gray-400 uppercase">Type</th>
              <th className="px-5 py-3 text-center text-xs font-bold text-gray-400 uppercase">Validée</th>
              <th className="px-5 py-3 text-right text-xs font-bold text-gray-400 uppercase">Montant</th>
              <th className="px-5 py-3 text-center text-xs font-bold text-gray-400 uppercase">Actions</th>
            </tr>
          </thead>
          <tbody>
            {transactions
              .filter(t => t.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          getCategoryName(t.id_cat)?.toLowerCase().includes(searchTerm.toLowerCase()))
              .map((t) => (
              <tr key={t.id_transac} className="hover:bg-gray-50 transition border-b border-gray-100 last:border-0">
                <td className="px-5 py-4">
                  <p className="font-bold text-gray-800">{t.description || "---"}</p>
                </td>
                <td className="px-5 py-4 text-sm text-gray-500">{t.date_mouvement}</td>
                <td className="px-5 py-4">
                  <span className="text-sm text-gray-600 font-medium">{getCategoryName(t.id_cat)}</span>
                </td>
                <td className="px-5 py-4 text-center">
                  <span className={`px-2 py-1 rounded-md text-[10px] font-bold ${t.type === 'Recette' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {t.type.toUpperCase()}
                  </span>
                </td>
                <td className="px-5 py-4 text-center">
                  <span className={`px-2 py-1 rounded-md text-[10px] font-bold ${t.valide ? 'bg-blue-100 text-blue-700' : 'bg-yellow-100 text-yellow-700'}`}>
                    {t.valide ? "✓ OUI" : "⏳ NON"}
                  </span>
                </td>
                <td className={`px-5 py-4 text-right font-bold ${t.type === 'Recette' ? 'text-green-600' : 'text-red-600'}`}>
                  {t.type === 'Dépense' ? '-' : '+'}{t.montant.toFixed(2)} €
                </td>
                <td className="px-5 py-4 text-center space-x-2">
                  {isAdmin ? (
                    <>
                      <button onClick={() => handleEditTransaction(t)} className="text-blue-400 hover:text-blue-600 transition-colors">
                        <i className="fa-solid fa-pencil"></i>
                      </button>
                      <button onClick={() => handleDeleteTransaction(t.id_transac)} className="text-red-400 hover:text-red-600 transition-colors">
                        <i className="fa-solid fa-trash-can"></i>
                      </button>
                    </>
                  ) : (
                    <span className="text-xs text-gray-400">Lecture seule</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* MODAL FORMULAIRE TRANSACTION */}
      {isModalOpen && (
        <TransactionForm
          onClose={() => {
            setIsModalOpen(false);
            setEditingTransaction(null);
          }}
          onSubmit={handleSaveTransaction}
          evenements={events}
          categories={categories}
          initialData={editingTransaction || undefined}
        />
      )}

    </Layout>
  );
}